function execute() {
    return Response.success([
        {title: "New uploads", input: "https://3hentai.net", script: "gen.js"}
    ]);
}