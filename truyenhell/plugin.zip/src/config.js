let BASE_URL = 'https://truyensex.moe/';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}