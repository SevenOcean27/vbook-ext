let BASE_URL = 'https://www.toptruyento.pro';
let BASE_URL1 = 'https://toptruyenww.pro'
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}