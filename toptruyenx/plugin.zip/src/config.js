let BASE_URL = 'https://www.toptruyentv5.pro';
let BASE_URL1 = 'https://toptruyentv3.pro'
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}