let BASE_URL = 'https://www.toptruyentv2.pro';
let BASE_URL1 = 'https://toptruyentv2.pro'
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}