let BASE_URL = 'https://www.toptruyen369.net';
let BASE_URL1 = 'https://toptruyentv.net'
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}