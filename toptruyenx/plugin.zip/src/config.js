let BASE_URL = 'https://www.toptruyentv9.com';
let BASE_URL1 = 'https://toptruyentv7.pro'
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}