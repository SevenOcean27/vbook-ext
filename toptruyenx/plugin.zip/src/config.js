let BASE_URL = 'https://www.toptruyentv10.com';
let BASE_URL1 = 'https://toptruyentv9.com'
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}