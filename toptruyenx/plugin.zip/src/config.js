let BASE_URL = 'https://www.toptruyentv.net';
let BASE_URL1 = 'https://toptruyen28.net'
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}