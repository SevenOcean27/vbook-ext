let BASE_URL = 'https://www.toptruyentv6.pro';
let BASE_URL1 = 'https://toptruyentv5.pro'
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}