let BASE_URL = 'https://www.toptruyen28.net';
let BASE_URL1 = 'https://toptruyenday.net'
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}