let BASE_URL = 'https://www.toptruyentv11.com';
let BASE_URL1 = 'https://toptruyentv10.com'
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}